package AssignmentGreenStitch.Assignment.Model;

public enum Role {
    USER,
    ADMIN
}
